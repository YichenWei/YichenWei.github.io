It includes the experiment results for Berkeley300 database in the following paper

Geodesic Saliency Using Background Priors, Yichen Wei, Fang Wen, Wangjiang Zhu, and Jian Sun, ECCV 2012.

There are two geodesic saliency methods, GS_GD (using regular grid) and GS_SP (using superpixel). For each, results include:

    1. precision-recall curves in PRCurve.txt. Column 1/2: precision/recall

    2. per image precision recall in perImage.txt. Each line is for one image: imageName    threshold    precision    recall    F-Measure

        threshold is set as twice of the mean saliency in each image adaptively, as suggested by [1].
        F_Measure = (1 + beta^2) * Precision * Recall / (beta^2 * Precision + Recall), and beta^2 is set to be 0.3 as in [1].

    3. all saliency maps (normalized to [0, 255]) in a sub-folder named dataset_method.


Below are mean precision/recall/F-Measure statistics obtained from above results, by running DrawPR.m.

Database    Method  Precision   Recall    F-Measure
Berkeley300 GS_GD   0.682160    0.503327  0.572403
Berkeley300 GS_SP   0.680629    0.511530  0.575438

Note that Berkeley300 database has two images(27059.jpg, 374067.jpg) without salient object mask. They are removed from all computation.

In case of any questions, please send email to yichenw@microsoft.com

[1]. R. Achanta, S. S. Hemami, F. J. Estrada, and S. S��usstrunk. Frequency-tuned salient region detection. In CVPR.