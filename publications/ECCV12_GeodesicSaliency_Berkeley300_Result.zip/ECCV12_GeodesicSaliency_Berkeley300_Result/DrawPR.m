%dataset = 'MSRA1000';
dataset = 'Berkeley300';
methods = {'GS_GD','GS_SP'};
methods_colors = {'r', 'b'};
methods_strs = {'GS\_GD','GS\_SP'};

%% load PRCurve.txt and draw PR curves
figure
hold on
for m = 1:length(methods)
    prFileName = strcat(dataset, '_', methods{m}, '_PRCurve.txt');
    R = load(prFileName);
    precision = R(:, 1);
    recall = R(:, 2);
    plot(recall, precision, methods_colors{m});
end
hold off
grid on
legend(methods_strs, 'Location', 'SouthWest');
xlabel(strcat('Recall (', dataset, ')'));
ylabel('Precision');

%% calculate mean precision/recall/F-measure
%F_Measure = (1 + beta^2) * Precision * Recall / (beta^2 * Precision +
%Recall), beta^2 is set to be 0.3 as in [1].
%[1]. R. Achanta, S. S. Hemami, F. J. Estrada, and S. S��usstrunk.
%      Frequency-tuned salient region detection. In CVPR.

for m = 1:length(methods)
    perImgFileName = strcat(dataset, '_', methods{m}, '_perImage.txt');    
    R = load(perImgFileName);

    Precision = R(:,3);
    Recall = R(:,4);
    F_measure = R(:, 5);

    fprintf('Dataset: %s, Method: %s\n', dataset, methods{m});
    fprintf('Recall: %f, Precision: %f, F-measure: %f\n\n', mean(Recall), mean(Precision), mean(F_measure));
end
