It includes the experiment results for MSRA1000 database in the following paper

Geodesic Saliency Using Background Priors, Yichen Wei, Fang Wen, Wangjiang Zhu, and Jian Sun, ECCV 2012.

There are two geodesic saliency methods, GS_GD (using regular grid) and GS_SP (using superpixel). For each, results include:

    1. precision-recall curves in PRCurve.txt. Column 1/2: precision/recall

    2. per image precision recall in perImage.txt. Each line is for one image: imageName    threshold    precision    recall    F-Measure

        threshold is set as twice of the mean saliency in each image adaptively, as suggested by [1].
        F_Measure = (1 + beta^2) * Precision * Recall / (beta^2 * Precision + Recall), and beta^2 is set to be 0.3 as in [1].

    3. all saliency maps (normalized to [0, 255]) in a sub-folder named dataset_method.


Below are mean precision/recall/F-Measure statistics obtained from above results, by running DrawPR.m.

Database    Method  Precision   Recall    F-Measure
MSRA1000    GS_GD   0.795478    0.854979  0.791398
MSRA1000    GS_SP   0.812730  	0.887631  0.814239

In case of any questions, please send email to yichenw@microsoft.com

[1]. R. Achanta, S. S. Hemami, F. J. Estrada, and S. S��usstrunk. Frequency-tuned salient region detection. In CVPR.